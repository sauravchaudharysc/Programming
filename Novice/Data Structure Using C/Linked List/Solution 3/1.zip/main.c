#include<stdio.h>
#include<malloc.h>
struct node{
    int data;
    struct node* next;
};
typedef struct node node;

node *createNode(node *head){
    int d;
    printf("Enter data - ");
    scanf("%d",&d);
    node *p = (node*)malloc(sizeof(node));
    if(head==NULL){
        p->data = d;
        p->next = NULL;
        head = p;
        return head;
    }
    p->data = d;
    head->next = p;
    p->next = NULL;
    head = p;
    return head;
}

void print(node *heada){
    node *p = (node*)malloc(sizeof(node));
    p = heada;
    if(p==NULL){
        printf("Linked List is empty ");
        return;
    }
    while(p->next!=NULL){
        printf("%d -- ",p->data);
        p = p->next;
    }
    printf("NULL\n");
}

int length(node *head){
    int count=0;
    if(!head){
        return 0;
    }
    while(head->next!=NULL){
        head = head->next;
        count++;
    }
    return count;
}

void breakNode(node *head,int l){
    int x = l/2;
    node *p = head;
    node *q = NULL;
    int count=1;
    while(count<x){
        head = head->next;
        count++;
    }
    q = head->next;
    head->next = NULL;

    node *t = q;
    count++;
    while(count<l){
        q = q->next;
        count++;
    }
    q->next = p;
    printf("\nAfter splitting and merging the list : ");
    while(t!=NULL){
        printf("%d -> ",t->data);
        t = t->next;
    }
    printf("NULL\n");
}

int main(){
    node *head = (node*)malloc(sizeof(node));
    node *heada = (node*)malloc(sizeof(node));
    head = NULL;
    heada = NULL;
    int choice,count=0;
    for(int i=0;i<10;i++)
    {
        head = createNode(head);
        count++;
        if(count==1){
            heada = head;
        }
    }    
    print(heada);
    int x = length(heada);
    printf("Length of the Linked List - %d\n",x);
    breakNode(heada,x);
}

