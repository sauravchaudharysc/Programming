#include <stdio.h>
#include <stdlib.h>
struct node
{
int info;
struct node *next;
};
typedef struct node NODE;
void display(NODE *head)
{
    NODE *temp=head->next;
    while(temp!=head)
    {
        printf("%d ",temp->info);
        temp=temp->next;
    }
}
NODE *insert_start(NODE *head,int x)
{
    NODE *q;
    q=(NODE*)malloc(sizeof(NODE));
    q->info=x;
    if(head->next==head)
     {
      q->next=head;
      head->next=q;
      return head;
     }
    else
     q->next=head->next;
     head->next=q;
    
}
NODE *insert_end(NODE *head,int x)
{
    NODE *q,*p=head->next;
    q=(NODE*)malloc(sizeof(NODE));
    q->info=x;
    if(head->next==head)
    { 
      
      q->next=head;
      head->next=q;
      return head;
    }  
    while(p->next!=head)
    p=p->next;
    q->next=p->next;
    p->next=q;
    return head;
}
NODE *delete_start(NODE *head)
{
    NODE *p;
    if(head->next==head)
    {
        printf("The list is empty");
        return NULL;
    }
    p=head->next;
    printf("Element removed is %d\n",head->next->info);
    head->next=head->next->next;
    free(p);
    return head;
}

NODE *delete_end(NODE *head)
{
    NODE *p,*q=head->next;
    if(head->next==head)
    {
        printf("The list is empty\n");
        return NULL;
    }
    else if(head->next->next==head)
    {
        printf("Element removed is %d\n",head->next->info);
        free(q);
        return head;
    }
    while(q->next!=head)
    {p=q;
    q=q->next;}
    printf("Element removed is %d\n",q->info);
    p->next=q->next;
    free(q);
    return head;
}
int main()
{
    NODE *head=(NODE*)malloc(sizeof(NODE));
    head->next=head;


     int option,k=1,data,key;
    while(k)
    {
        printf("*********MAIN MENU*********");
        printf("\n1.Insert Start\n2.Insert End\n3.Delete Start\n4.Delete End\n5.Display\n8.Exit\n");
        printf("Enter your choice :-  ");
        scanf("%d",&option);
        switch(option)
        {
        case 1:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_start(head,data);
            break;
        case 2:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_end(head,data);
            break;
        case 3:
            head=delete_start(head);
            break;
        case 4:
            head=delete_end(head);
            break;
        case 5:
            display(head);
            break;
        }
    }
}