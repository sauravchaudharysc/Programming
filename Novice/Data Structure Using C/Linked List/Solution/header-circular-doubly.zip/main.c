#include<stdio.h>
#include<stdlib.h>
struct node    {
    int info;
    struct node *next;
    struct node *prev;
};
typedef struct node NODE;
NODE* createList()    {
    NODE *head = (NODE*)malloc(sizeof(NODE));
    NODE *q = (NODE*)malloc(sizeof(NODE));
    printf("Enter an element to insert in the list: ");
    scanf("%d",&q->info);
    head->info = 1;
    head->next = q;
    q->next = head;
    return head;
}
NODE* insertAtStart(int x, NODE *head)    {
    NODE *q = (NODE*)malloc(sizeof(NODE));
    q->info = x;
    q->next = head->next;
    q->prev = head;
    head->next = q;
    head->info++;
    return head;
}
NODE* insertAtEnd( int x, NODE *head)    {
    NODE *q = (NODE*)malloc(sizeof(NODE));
    NODE *p = head;
    q->info = x;
    q->next = head;
    while(p->next != head)
        p = p->next;
    p->next = q;
    q->prev = p;
    head->info++;
    return head;
}
NODE* insertBefore( int x, int y, NODE *head )    {
    NODE *q = (NODE*)malloc(sizeof(NODE));
    NODE *p = head->next;
    q-> info = x;
    while(p->info != y)
        p = p->next;
    q->next = p;
    q->prev = p->prev;
    p->prev->next = q;
    p->prev = q;
    head->info++;
    return head;
}
NODE* insertAfter( int x, int y, NODE *head )    {
    NODE *q = (NODE*)malloc(sizeof(NODE));
    NODE *p = head->next;
    q->info = x;
    while(p->info != y)
        p = p->next;
    q->next = p->next;
    q->prev = p;
    p->next = q;
    q->next->prev = q;
    head->info++;
    return head;
}
NODE* deleteFirst( NODE *head )    {
    NODE *p = head->next;
    if(head->next == NULL)
    {
        printf("List is empty.\n");
        return NULL;
    }
    head->next = p->next;;
    head->info--;
    free(p);
    return head;
}
NODE* deleteLast( NODE *head )    {
    NODE *p, *q = head->next;
    if(head->next == NULL)
    {
        printf("List is empty.\n");
        return NULL;
    }
    while(q->next != head)
    {    p = q;
        q = q->next;
    }
    p->prev = q->prev;
    free(q);
    p->next = head;
    head->info--;
    return head;
}
NODE* deleteX( NODE *head , int x )    {
    NODE *p,*q = head->next;
    if(head->next == NULL)
    {
        printf("List is empty.\n");
        return NULL;
    }
    while(q->info != x)
    {    p = q;
        q = q->next;
    }
    p->next = q->next;
    q->next->prev = p;
    free(q);
    head->info--;
    return head;
}
NODE* displayList( NODE *head )    {
    NODE *p = head->next;
    do
    {
        printf("%d\n",p->info);
        p = p->next;
    }while(p != head);
    return head;
}
void displaynum(NODE *head)
{
    printf("Number of elements in the List = %d\n",head->info);
}
int main()
{
    int c, n, e;
    NODE *head = NULL;
    printf("\t\t\tLIST\n1. Create a Linked List\n2. Insert an element at the start of the Linked List\n3. Insert an element at the end of the Linked List\n4. Insert an element before an existing element whose information is x\n5. Insert an element after an existing element whose information is x\n6. Delete the first element of the Linked List\n7. Delete the last element of the Linked list\n8. Delete the element whose information is x\n9. Display the contents of the Linked List\n10. Display the number of elements in the list\n11. Exit");
    do
    {
        printf("\nEnter your choice(1-11): ");
        scanf("%d",&c);
        switch(c)
        {
            case 1:    head = createList();
                break;
            case 2: printf("Insert an element to insert: ");
                scanf("%d", &n);
                head = insertAtStart(n, head);
                break;
            case 3: printf("Insert an element to insert: ");
                scanf("%d", &n);
                head = insertAtEnd(n, head);
                break;
            case 4: printf("Insert an element to insert: ");
                scanf("%d", &n);
                printf("Enter the existing element: ");
                scanf("%d", &e);
                head = insertBefore(n, e, head);
                break;
            case 5: printf("Insert an element to insert: ");
                scanf("%d", &n);
                printf("Enter the existing element: ");
                scanf("%d", &e);
                head = insertAfter(n, e, head);
                break;
            case 6: head = deleteFirst(head);
                break;
            case 7: head = deleteLast(head);
                break;
            case 8: printf("Enter the information of the element to be deleted: ");
                scanf("%d",&e);
                head = deleteX(head, e);
                break;
            case 9: printf("The elements in the Linked List are as follow : \n");
                head = displayList(head);
                break;
            case 10: displaynum(head);
                break;
            case 11: printf("Exiting....\n");
                break;
        }
    }while(c!=11);
}