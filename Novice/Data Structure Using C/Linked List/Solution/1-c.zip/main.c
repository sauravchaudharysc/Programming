#include <stdio.h>
#include<stdlib.h>
struct Node{
    int info;
    struct Node *next;
};
typedef struct Node NODE;
    void display(NODE *head)
    {
        NODE *p=head;
       if(p==NULL)
       printf("Empty\n");
       else
       {
        while(p!=NULL)
        {
            printf("%d \t",p->info);
            p=p->next;
        }
        printf("\n");
        }
    }
    
    NODE *insert_start(NODE *head,int x)
    {
        NODE *q;
        q=(NODE*)malloc(sizeof(NODE));
        q->info=x;
        q->next=head;
        return q;
    }
    NODE *insert_end(NODE *head,int x)
    {
        NODE *p=head,*q;
        q=(NODE*)malloc(sizeof(NODE));
        q->info=x;
        q->next=NULL;
        if(head==NULL)
        {
           q->next=head;
        return q;
        }
        while(p->next!=NULL)
            p=p->next;
            p->next=q;
        return head;
    }
    NODE *insert_before(NODE *head,int x,int y)
    {
        NODE *p=head,*q;
        if(head==NULL)
        {
            printf("List is empty");
        }
        if(y==head->info)
        {
            q=(NODE*)malloc(sizeof(NODE));
            q->info=x;
            q->next=head;
        return q;
        }
        while(p->next!=NULL)
        {
            if(p->next->info==y)
            {
             q=(NODE*)malloc(sizeof(NODE));
             q->info=x;
             q->next=p->next;
             p->next=q;
             return head;
            }
         p=p->next;
        }
     printf("%d not present in the list\n",y);
     return head;
    }
    NODE *insert_arbitrary(NODE *head,int x,int y)
    {
        NODE *p=head,*q;
        if(y==head->info)
        {
            q=(NODE*)malloc(sizeof(NODE));
            q->info=x;
            q->next=head;
        return q;
        }
        while(p->info!=y)
        p=p->next;
        q->info=x;
        q->next=p->next;
        p=q;
        return head;
    }
    NODE *insert_after(NODE *head,int x,int y)
    {
        NODE *p=head,*q;
        while(p!=NULL)
        {
            if(p->info==y)
            {
                q=(NODE*)malloc(sizeof(NODE));
                q->info=x;
                q->next=p->next;
                p->next=q;
                return head;
            }
         p=p->next;
        }
     printf("%d not present in the list\n",y);
     return head;
    }
    NODE *insert_pos(NODE *head,int x,int y)
    {
        NODE *p=head,*q;
        int i;
        for(i=1;i<y-1&&p!=NULL;i++)
            p=p->next;
        if(p==NULL)
            printf("In the List no of elements is less than %d\n",y);
        else
         {
             q=(NODE*)malloc(sizeof(NODE));
             q->info=x;
             if(y==1)
              {
                q->next=head;
                return q;
              }
             else
              {
                 q->next=p->next;
                 p->next=q;
               }
         }
        return head;

    }
    NODE *delete_start(NODE *head)
    {
        NODE *p=head;
        int item;
        if(head==NULL)
        {
            printf("List is empty\n");
            return NULL;
        }
        item=head->info;
        head=head->next;
        printf("%d \n",item);
        free(p);
        return head;
    }
    NODE *deleteAlt(NODE *head) 
{ 
    if (head == NULL) 
        return; 
  
    /* Initialize prev and node to be deleted */
    NODE *prev = head; 
    NODE *node = head->next; 
  
    while (prev != NULL && node != NULL) 
    { 
        /* Change next link of previous node */
        prev->next = node->next; 
  
        /* Free memory */
        free(node); 
       /* Update prev and node */
        prev = prev->next; 
        if (prev != NULL) 
            node = prev->next; 
    } 
    return head;
} 
    NODE *reverse(NODE* head)
    {
        NODE *prev,*ptr,*neext;
        prev=NULL;
        ptr=head;
        while(ptr!=NULL)
        {
            neext=ptr->next;
            ptr->next=prev;
            prev=ptr;
            ptr=neext;
        }
        head=prev;
        return head;
    }
    NODE *delete_end(NODE *head)
    {
        NODE *q=head,*p;
        if(head==NULL)
        {
            printf("List is empty\n");
            return NULL;
        }
        while(q->next!=NULL)
        {
            p=q;
            q=p->next;
        }
        free(q);
        p->next=NULL;
        return head;
    }
    NODE *delete_arbitrary(NODE *head,int x)
    {
        NODE *p,*q=head;
        if(head==NULL)
        {
            printf("List is empty\n");
            return NULL;
        }
        if(head->info==x)
        {
            head=head->next;
            free(q);
            return head;
        }
        while(q->info!=x&&q->next!=NULL)
        {
            p=q;
            q=q->next;

        }
        if(q->next==NULL&&q->info!=x)
        {
            printf("key not find");
            return head;
        }
         p->next=q->next;
            free(q);
            return head;

    }

    NODE* delete_before(NODE *head,int y)
    {
        NODE *p=NULL,*q=head,*r;
            if(head==NULL)
        {
            printf("List is empty\n");
            return NULL;
        }

        while(q->info!=y)
        {r=p;
        p=q;
        q=q->next;
        }
        r->next=p->next;
        return head;
    }
    NODE *delete_position(NODE *head,int y)
    {
        NODE *p,*q=head;
        int i;
        for(i=1;i<=y-1&&q!=NULL;i++)
        {
            p=q;
            q=q->next;
        }
        if(q==NULL)
        {
            printf("Less no of elements in list\n");
            return NULL;
        }
        else
        {
            if(y==1)
            {p=q;
            q=q->next;
                free(p);
                return q;
            }
            else
           {p->next=q->next;
            free(q);
            return head;
           }

        }
    }
    NODE *delete_after(NODE *head,int y)
    {
        NODE *p,*q=head;
        if(head==NULL)
        {
            printf("List is empty\n");
            return NULL;
        }
        if(head->next==NULL)
        {
            printf("Next Element");
            return head;
        }

        while(q->info!=y)
        {
            q=q->next;
        }
        if(q->next==NULL)
        {
            printf("Last node can't  be deleted");
            return ;
        }
        p=q->next;
        q->next=p->next;
        free(p);
        return head;
    }
    void count(NODE *head)
    {
        NODE *p;
        int count=0;
        p=head;
        while(p!=NULL)
        {
            p = p->next;
            count++;
        }
        printf("Number of elements are %d\n",count);
    }
    NODE *create_list(NODE *head)
    {
        int i,n,data;
        printf("Enter the number of nodes : ");
        scanf("%d",&n);
        head=NULL;
        if(n==0)
        return head;
        printf("Enter the element to be inserted : ");
        scanf("%d",&data);
        head=insert_start(head,data);
        printf("%d ",head->info);
        for(i=2; i<=n; i++)
        {
        printf("Enter the element to be inserted : ");
        scanf("%d",&data);
        head=insert_end(head,data);
        }
        return head;
    }
    void search(NODE *start,int item)
    {
        NODE *p=start;
        int pos=1;
        while(p!=NULL)
        {
                if(p->info == item)
            {
                printf("Item %d found at position %d\n",item,pos);
                return;
            }
         p=p->next;
         pos++;
        }
        printf("Item %d not found in list\n",item);
    }
int main()
{
NODE *head=NULL;
int choice,data,item,pos;
while(1)
{
    printf("1.Create List\n");
    printf("2.Display\n");
    printf("3.Count\n");
    printf("4.Search\n");
    printf("5.Add to empty list / Add at beginning\n");
    printf("6.Add at end\n");
    printf("7.Add after node\n");
    printf("8.Add before node\n");
    printf("9.Add at position\n");
    printf("10.Delete at Arbitrary \n");
    printf("11.Delete at End \n");
    printf("12.Delete at Start \n");
    printf("13.Delete at Position \n");
    printf("14.Delete After node\n");
    printf("15.Delete Before node\n");
    printf("16.Reverse\n");
    printf("17.Delete Alternates Node\n");
    printf("Enter your choice : ");
    scanf("%d",&choice);

 switch(choice)
        {
        case 1:
            head=create_list(head);
         break;
        case 2:
            display(head);
         break;
        case 3:
            count(head);
         break;
        case 4:
            printf("Enter the element to be searched : ");
            scanf("%d",&data);
            search(head,data);
         break;
        case 5:
            printf("Enter the element to be inserted : ");
            scanf("%d",&data);
            head=insert_start(head,data);
         break;
        case 6:
            printf("Enter the element to be inserted : ");
            scanf("%d",&data);
            head=insert_end(head,data);
         break;
        case 7:
            printf("Enter the element to be inserted : ");
            scanf("%d",&data);
            printf("Enter the element after which to insert : ");
            scanf("%d",&item);
            head=insert_after(head,data,item);
         break;
        case 8:
            printf("Enter the element to be inserted : ");
            scanf("%d",&data);
            printf("Enter the element before which to insert: ");
            scanf("%d",&item);
            head=insert_before(head,data,item);
         break;
        case 9:
            printf("Enter the element to be inserted : ");
            scanf("%d",&data);
            printf("Enter the position at which to insert : ");
            scanf("%d",&pos);
            head=insert_pos(head,data,pos);
         break;
        case 10:
            printf("Enter the element to be deleted : ");
            scanf("%d",&data);
            head=delete_arbitrary(head, data);
         break;
        case 11:
            head=delete_end(head);
         break;
        case 12:
            head=delete_start(head);
         break;
        case 13:
            printf("Enter the position at which to delete : ");
            scanf("%d",&pos);
            head=delete_position(head,pos);
         break;
        case 14:
            printf("Enter the element after which to delete : ");
            scanf("%d",&pos);
            head=delete_after(head,pos);
         break;
        case 15:
            printf("Enter the element before which to delete : ");
            scanf("%d",&pos);
            head=delete_before(head,pos);
            break;
        case 16:
            head=reverse(head);
            break;
        case 17:
            head=deleteAlt(head);
            break;    
        default:
        printf("Wrong choice\n");
}/*End of switch*/
}/*End of while*/
return 0;
}



