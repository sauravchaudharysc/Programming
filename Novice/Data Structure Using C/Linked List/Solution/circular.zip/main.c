
#include <stdio.h>
#include<stdlib.h>
struct node{
    int info;
    struct node* next;
};
typedef struct node NODE;

void display(NODE *head)
{   
    NODE *temp=head;
    if(head==NULL)
        printf("List is Empty");
    else
        do{
            printf("%d ",temp->info);
            temp=temp->next;
        }while(temp!=head);
}

NODE *insert_start(NODE *head,int x)
{
    NODE *q;
    q=(NODE*)malloc(sizeof(NODE));
     q->info=x;
    if(head==NULL)
     {
        q->next=q;
        return q;
     }
    else
        q->next=head->next;
        head->next=q;
    return head;
}

NODE *insert_end(NODE *head,int x)
{
    NODE *p=head,*q;
    q=(NODE*)malloc(sizeof(NODE));
     q->info=x;
    if(head==NULL)
     {
        q->next=q;
        return q;
     }
    else
    {
     while(p->next!=head)
     p=p->next;
     q->next=p->next;
     p->next=q;
     return head;
    }
}
NODE *delete_start(NODE *head)
{
    NODE *p=head,*q=head;
    if(head==NULL)
    {printf("List is Empty");
    return NULL;}
    else if(head->next==head)
    {
        printf("The element deleted is %d\n",head->info);
        free(head);
        return NULL;
    }
    else
     {
      while(p->next!=head)
      p=p->next;
      p->next=head->next;
      printf("The element deleted is %d\n",head->info);
      head=head->next;
      free(q);
      return head;
     }
}
NODE *delete_end(NODE *head)
{
    NODE *p=head,*q;
    if(head==NULL)
    {printf("List is Empty");
    return NULL;}
    else if(head->next==head)
    {
        printf("The element deleted is %d\n",head->info);
        free(head);
        return NULL;
    }
    else
     {
      while(p->next->next!=head)
      p=p->next;
      printf("The element deleted is %d\n",p->next->info);
      q=p->next;
      p->next=head;
      free(q);
      return head;
     }
}
int main()
{
    NODE *head=NULL;
     int option,k=1,data,key;
    while(k)
    {
        printf("*********MAIN MENU*********");
        printf("\n1.Insert Start\n2.Insert End\n3.Delete Start\n4.Delete End\n5.Display\n8.Exit\n");
        printf("Enter your choice :- \n");
        scanf("%d",&option);
        switch(option)
        {
        case 1:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_start(head,data);
            break;
        case 2:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_end(head,data);
            break;    
        case 3:
            head=delete_start(head);
            break;
        case 4:
            head=delete_end(head);
            break;
        case 5:
            display(head);
            break;
        }
    }
}    

