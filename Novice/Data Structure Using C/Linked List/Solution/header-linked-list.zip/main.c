#include <stdio.h>
#include <stdlib.h>
struct node
{
int info,count;
struct node *next;
};
typedef struct node NODE;
int count1=0;
void display(NODE *head)
    {
        NODE *p=head->next;
       if(p==NULL)
       printf("Empty\n");
       else
       {
        while(p!=NULL)
        {
            printf("%d \t",p->info);
            p=p->next;
        }
        printf("\n");
        }
    }
NODE *insert_start(NODE *head,int x)
{   
    head->count=count1+1;
    NODE *q;
    q=(NODE*)malloc(sizeof(NODE));
    q->info=x;
    q->next=head->next;
    head->next=q;
    return head;
}
NODE *insert_end(NODE *head,int x)
{
    head->count=count1+1;
    NODE *q,*p=head;
    q=(NODE*)malloc(sizeof(NODE));
    q->info=x;
    q->next=NULL;
    if(head->next==NULL)
    {
        q->next=head->next;
        head->next=q;
        return head;
    }
    while(p->next!=NULL)
    p=p->next;
    p->next=q;
    return head;
}
NODE *delete_start(NODE *head)
{
    NODE *p=head->next;
    if(head->next==NULL)
    {
        head->count=0;
        printf("The list is empty");
        return NULL;
    }
    head->count=count1-1;
    printf("The Element deleted is %d \n",head->next->info);
    head->next=head->next->next;
    free(p);
    return head;
}

NODE *delete_end(NODE *head)
{
    NODE *p,*q=head->next;
    if(q==NULL)
    {
        head->count=0;
        printf("The list is empty\n");
        return NULL;
    }
    if(q->next==NULL)
    {
        head->count=0;
        printf("Element removed is %d\n",q->info);
        free(q);
        return head;
    } 
    while(q->next!=NULL)
        {
            p=q;
            q=p->next;
        }
        head->count=count1-1;
        printf("The element deleted is %d \n",q->info);
        free(q);
        p->next=NULL;
        return head;
}
int main()
{
    NODE *head=(NODE*)malloc(sizeof(NODE));
    head->next=NULL;


     int option,k=1,data,key;
    while(k)
    {
        printf("*********MAIN MENU*********");
        printf("\n1.Insert Start\n2.Insert End\n3.Delete Start\n4.Delete End\n5.Display\n6.Count\n8.Exit\n");
        printf("Enter your choice :-  ");
        scanf("%d",&option);
        switch(option)
        {
        case 1:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_start(head,data);
            break;
        case 2:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_end(head,data);
            break;
        case 3:
            head=delete_start(head);
            break;
        case 4:
            head=delete_end(head);
            break;
        case 5:
            display(head);
            break;
        case 6:
            printf("The no of element is %d \n",head->count);
        }
    }
}
