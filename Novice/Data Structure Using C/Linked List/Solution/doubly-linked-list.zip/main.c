#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
    int info;
    struct Node *next,*prev;
}NODE;

NODE *insert_start(NODE *head,int x)
{
 NODE *q=(NODE*)malloc(sizeof(NODE));
 q->info=x;
 q->next=head;
 q->prev=NULL;
if(head==NULL)
 {
    head=q;
 }
else
 {q->next=head;
 q->next->prev=q;
 head=q;}
 
 return head;
}
NODE *insert_end(NODE *head,int x)
{
 NODE *p=head,*q; 
 q=(NODE*)malloc(sizeof(NODE));
 q->info=x;
 q->next=NULL;
if(head==NULL)
 {
    q->prev=NULL;
    head=q;
 }
else
 while(p->next!=NULL)
 p=p->next;
 q->prev=p;
 p->next=q;
 return head;
}
NODE *delete_start(NODE *head)
{
 NODE *p=head,*q;
if(head==NULL)
 {
    printf("List is empty");
 }
if(head->next==NULL&&head->prev==NULL)
{
    printf("The element deleted is %d\n",head->info);
    return NULL;
}
else
 printf("The element deleted is %d\n",head->info);
 head=head->next;
 free(p);
 return head;
}

NODE *delete_end(NODE *head)
{
 NODE *p=head,*q;
if(head==NULL)
 {
    printf("List is empty");
 }
if(head->next==NULL&&head->prev==NULL)
{
    printf("The element deleted is %d\n",head->info);
    return NULL;
}
else
 while(p->next!=NULL)
 {  q=p;
     p=p->next;
 }     
 printf("The element deleted is %d\n",p->info);
 q->next=NULL;
 free(p);
 return head;
}
void display(NODE *head)
{
    while(head!=NULL)
    {
        printf("%d\t",head->info);
        head=head->next;
    }
    printf("\n");
}
int main()
{
    NODE *head;
    head=NULL;


     int option,k=1,data,key;
    while(k)
    {
        printf("*********MAIN MENU*********");
        printf("\n1.Insert Start\n2.Insert End\n3.Delete Start\n4.Delete End\n5.Display\n6.Count\n8.Exit\n");
        printf("Enter your choice :-  ");
        scanf("%d",&option);
        switch(option)
        {
        case 1:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_start(head,data);
            break;
        case 2:
            printf("Enter your data :-");
            scanf("%d",&data);
            head=insert_end(head,data);
            break;
        case 3:
            head=delete_start(head);
            break;
        case 4:
            head=delete_end(head);
            break;
        case 5:
            display(head);
            break;
        }
    }
}

